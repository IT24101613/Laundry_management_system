package com.laundry.freshfoldlaundryapp.controller;

import com.laundry.freshfoldlaundryapp.dto.UserProfileDto;
import com.laundry.freshfoldlaundryapp.model.User;
import com.laundry.freshfoldlaundryapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import java.security.Principal;

@Controller
public class ProfileController {

    @Autowired
    private UserService userService;

    @GetMapping("/profile")
    public String showProfilePage(Model model, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        if (user == null) {
            // Handle case where user is not found, maybe redirect to login or error page
            return "redirect:/login";
        }

        UserProfileDto profileDto = new UserProfileDto();
        profileDto.setFirstName(user.getFirstName());
        profileDto.setLastName(user.getLastName());
        profileDto.setPhoneNumber(user.getPhoneNumber());
        profileDto.setAddress(user.getAddress());

        model.addAttribute("profileDto", profileDto);
        model.addAttribute("role", user.getRole());
        return "profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute UserProfileDto profileDto, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        if (user != null) {
            user.setFirstName(profileDto.getFirstName());
            user.setLastName(profileDto.getLastName());
            user.setPhoneNumber(profileDto.getPhoneNumber());
            user.setAddress(profileDto.getAddress());
            userService.save(user);

            if (user.getRole().equals("CUSTOMER")) {
                return "redirect:/customer-dashboard";
            } else if (user.getRole().equals("STAFF")) {
                return "redirect:/staff-dashboard";
            } else {
                return "redirect:/profile";
            }
        }
            return "redirect:/profile";
        }

    @PostMapping("/profile/delete")
    public String deleteProfile(Principal principal,
                               HttpServletRequest request,
                               HttpServletResponse response,
                               RedirectAttributes redirectAttributes) {
        try {
            User user = userService.findByEmail(principal.getName());
            if (user != null) {
                // Check if user has any pending orders or important data
                // You might want to add additional checks here based on your business logic

                // Delete the user account
                userService.deleteUser(user.getId());

                // Logout the user after account deletion
                Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null) {
                    new SecurityContextLogoutHandler().logout(request, response, auth);
                }

                redirectAttributes.addFlashAttribute("message", "Your account has been successfully deleted.");
                redirectAttributes.addFlashAttribute("messageType", "success");
                return "redirect:/login?deleted=true";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "An error occurred while deleting your account. Please try again.");
            redirectAttributes.addFlashAttribute("messageType", "error");
            return "redirect:/profile?error=true";
        }

        return "redirect:/profile";
    }

    @PostMapping("/profile/delete/confirm")
    public String confirmDeleteProfile(@RequestParam("confirmPassword") String confirmPassword,
                                     Principal principal,
                                     HttpServletRequest request,
                                     HttpServletResponse response,
                                     RedirectAttributes redirectAttributes) {
        try {
            User user = userService.findByEmail(principal.getName());
            if (user != null) {
                // Verify the password before deletion
                if (userService.checkPassword(user, confirmPassword)) {
                    // Delete the user account
                    userService.deleteUser(user.getId());

                    // Logout the user after account deletion
                    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                    if (auth != null) {
                        new SecurityContextLogoutHandler().logout(request, response, auth);
                    }

                    redirectAttributes.addFlashAttribute("message", "Your account has been successfully deleted.");
                    redirectAttributes.addFlashAttribute("messageType", "success");
                    return "redirect:/login?deleted=true";
                } else {
                    redirectAttributes.addFlashAttribute("message", "Incorrect password. Account deletion cancelled.");
                    redirectAttributes.addFlashAttribute("messageType", "error");
                    return "redirect:/profile?passwordError=true";
                }
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "An error occurred while deleting your account. Please try again.");
            redirectAttributes.addFlashAttribute("messageType", "error");
            return "redirect:/profile?error=true";
        }

        return "redirect:/profile";
    }

}