//package com.laundry.laundry_management_system.controller;
//
//
//import jakarta.servlet.http.HttpSession;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import com.laundry.laundry_management_system.model.Cart;
//import com.laundry.laundry_management_system.model.CartItem;
//import com.laundry.laundry_management_system.service.CartService;
//
//@RestController
//@RequestMapping("/cart")
//public class CartController {
//
//    private final CartService cartService;
//
//    public CartController(CartService cartService) {
//        this.cartService = cartService;
//    }
//
//    @GetMapping
//    public ResponseEntity<Cart> getCart(HttpSession session) {
//        return ResponseEntity.ok(cartService.getCart(session));
//    }
//
//    @PostMapping("/items")
//    public ResponseEntity<Cart> addItem(@RequestBody CartItem item, HttpSession session) {
//        // Optionally validate item fields here
//        return ResponseEntity.ok(cartService.addItem(session, item));
//    }
//
//    @DeleteMapping("/items/{index}")
//    public ResponseEntity<Cart> removeItem(@PathVariable int index, HttpSession session) {
//        return ResponseEntity.ok(cartService.removeItem(session, index));
//    }
//
//    @PostMapping("/clear")
//    public ResponseEntity<Void> clear(HttpSession session) {
//        cartService.clear(session);
//        return ResponseEntity.noContent().build();
//    }
//}
//
