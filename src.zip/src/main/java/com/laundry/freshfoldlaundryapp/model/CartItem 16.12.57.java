//package com.laundry.laundry_management_system.model;
//
//import java.math.BigDecimal;
//
//public class CartItem {
//    private String serviceType;
//    private int quantity;
//    private String notes;
//    private BigDecimal unitPrice;
//    private String ClothType;
//
//    public CartItem() {
//    }
//
//    public CartItem(String serviceType, int quantity, String notes, BigDecimal unitPrice, String clothType) {
//        this.serviceType = serviceType;
//        this.quantity = quantity;
//        this.notes = notes;
//        this.unitPrice = unitPrice;
//        ClothType = clothType;
//    }
//
//    public String getServiceType() {
//        return serviceType;
//    }
//
//    public void setServiceType(String serviceType) {
//        this.serviceType = serviceType;
//    }
//
//    public int getQuantity() {
//        return quantity;
//    }
//
//    public void setQuantity(int quantity) {
//        this.quantity = quantity;
//    }
//
//    public String getNotes() {
//        return notes;
//    }
//
//    public void setNotes(String notes) {
//        this.notes = notes;
//    }
//
//    public BigDecimal getUnitPrice() {
//        return unitPrice;
//    }
//
//    public String getClothType() {
//        return ClothType;
//    }
//
//    public void setClothType(String clothType) {
//        ClothType = clothType;
//    }
//
//    public void setUnitPrice(BigDecimal unitPrice) {
//        this.unitPrice = unitPrice;
//
//
//    }
//}
//
