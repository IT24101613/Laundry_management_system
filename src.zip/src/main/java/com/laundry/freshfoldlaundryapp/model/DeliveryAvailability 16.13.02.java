//package com.laundry.laundry_management_system.model;
//
//import jakarta.persistence.*;
//import java.time.LocalDate;
//import java.time.LocalTime;
//
//@Entity
//public class DeliveryAvailability {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private Long staffId;
//    private LocalDate date;
//    private LocalTime startTime;
//    private LocalTime endTime;
//
//    // Getters and setters
//    public Long getId() { return id; }
//    public void setId(Long id) { this.id = id; }
//    public Long getStaffId() { return staffId; }
//    public void setStaffId(Long staffId) { this.staffId = staffId; }
//    public LocalDate getDate() { return date; }
//    public void setDate(LocalDate date) { this.date = date; }
//    public LocalTime getStartTime() { return startTime; }
//    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
//    public LocalTime getEndTime() { return endTime; }
//    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
//}
//
