//package com.laundry.laundry_management_system.repository;
//
//import com.laundry.laundry_management_system.model.DeliveryAvailability;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.time.LocalDate;
//import java.util.List;
//
//public interface DeliveryAvailabilityRepository extends JpaRepository<DeliveryAvailability, Long> {
//    List<DeliveryAvailability> findByDateAfter(LocalDate date);
//    List<DeliveryAvailability> findByStaffId(Long staffId);
//}
//
