package com.laundry.laundry_management_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.laundry.laundry_management_system.model.Profile;

public interface ProfileRepository extends JpaRepository<Profile, Long> {
    Profile findByUserId(Long userId);
}