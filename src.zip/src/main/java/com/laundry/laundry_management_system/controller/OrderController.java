package com.laundry.laundry_management_system.controller;

import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.service.OrderService;
import com.laundry.laundry_management_system.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // Method to show the new order form
    @GetMapping("/index")
    public String showNewServiceTypeForm(Model model) {
        model.addAttribute("order", new Order());
        return "index";
    }

    @GetMapping("/select-clothes")
    public String showSelectClothes(Model model) {
        model.addAttribute("order", new Order());
        return "select-clothes";
    }

    @GetMapping("/order")
    public String showNewOrderForm(Model model) {
        model.addAttribute("order", new Order());
        return "order";
    }

    // Method to handle new order form submission
    @PostMapping("/order")
    public String placeNewOrder(@ModelAttribute("order") Order order,
                                @AuthenticationPrincipal CustomUserDetails userDetails,
                                RedirectAttributes redirectAttributes) {
        try {
            if (userDetails != null) {
                // Use simple customer ID approach
                order.setCustomerId(userDetails.getUserId());
                order.setStatus("PENDING");
                order.setOrderDate(LocalDateTime.now());
                //order.setAddress(order.getAddress());
                orderService.saveOrder(order);
                redirectAttributes.addFlashAttribute("successMessage", "Your order has been placed successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Authentication error. Please log in again.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to place order. Please try again.");
            logger.error("Error placing order", e);
        }

        return "redirect:/customer-dashboard";
    }
}
