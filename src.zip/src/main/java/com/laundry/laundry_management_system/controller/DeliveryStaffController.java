package com.laundry.laundry_management_system.controller;

import com.laundry.laundry_management_system.model.DeliveryAvailability;
import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.model.User;
import com.laundry.laundry_management_system.service.DeliveryStaffService;
import com.laundry.laundry_management_system.service.CustomUserDetails;
import com.laundry.laundry_management_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class DeliveryStaffController {
    @Autowired
    private DeliveryStaffService deliveryStaffService;

    @Autowired
    private UserService userService;

    @GetMapping("/delivery-staff-dashboard")
    public String showDeliveryStaffDashboard(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        Long deliveryStaffId = userDetails.getUserId();
        List<Order> deliveryOrders = deliveryStaffService.getAssignedDeliveryOrders(deliveryStaffId);
        for (Order order : deliveryOrders) {
            User customer = userService.getUserById(order.getCustomerId());
            if (customer != null) {
                order.setAddress(customer.getAddress());
            }
        }
        model.addAttribute("deliveryOrders", deliveryOrders);
        model.addAttribute("managerId", 23L); // Pass manager's userId
        model.addAttribute("currentUserId", deliveryStaffId); // Pass current delivery staff's userId
        return "delivery-staff-dashboard";
    }

    @PostMapping("/mark-order-delivered")
    public String markOrderAsDelivered(@RequestParam("orderId") Long orderId) {
        deliveryStaffService.markOrderAsDelivered(orderId);
        return "redirect:/delivery-staff-dashboard";
    }

    // View all availability slots for current delivery staff
    @GetMapping("/delivery-staff/availability")
    @ResponseBody
    public List<DeliveryAvailability> getAvailability(@AuthenticationPrincipal CustomUserDetails userDetails) {
        return deliveryStaffService.getAvailabilityForStaff(userDetails.getUserId());
    }

    // Add a new availability slot
    @PostMapping("/delivery-staff/availability")
    @ResponseBody
    public DeliveryAvailability addAvailability(@AuthenticationPrincipal CustomUserDetails userDetails, @RequestBody DeliveryAvailability availability) {
        availability.setStaffId(userDetails.getUserId());
        return deliveryStaffService.addAvailability(availability);
    }

    // Update an existing slot
    @PostMapping("/delivery-staff/availability/{id}")
    @ResponseBody
    public DeliveryAvailability updateAvailability(@PathVariable Long id, @RequestBody DeliveryAvailability availability) {
        return deliveryStaffService.updateAvailability(id, availability);
    }

    // For customers: fetch all future available slots
    @GetMapping("/available-delivery-slots")
    @ResponseBody
    public List<DeliveryAvailability> getAvailableSlots() {
        return deliveryStaffService.getFutureAvailability();
    }
}
