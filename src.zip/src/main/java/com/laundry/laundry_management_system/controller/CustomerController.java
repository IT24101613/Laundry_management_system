package com.laundry.laundry_management_system.controller;

import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.service.CustomerService;
import com.laundry.laundry_management_system.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/customer-dashboard")
    public String showCustomerDashboard(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        // Use simple customer ID approach
        Long customerId = userDetails.getUserId();
        List<Order> orders = customerService.getOrdersForCustomer(customerId);
        model.addAttribute("orders", orders);
        return "customer-dashboard";
    }
}