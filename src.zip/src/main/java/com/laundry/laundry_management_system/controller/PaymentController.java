package com.laundry.laundry_management_system.controller;

import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.service.OrderService;
import com.laundry.laundry_management_system.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Controller
public class PaymentController {

    private final OrderService orderService;

    @Autowired
    public PaymentController(OrderService orderService) {
        this.orderService = orderService;
    }

    // Show payment page
    @GetMapping("/payment")
    public String showPaymentPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        if (userDetails != null) {
            model.addAttribute("customerId", userDetails.getUserId());
        }
        return "payment";
    }

    // Process payment via form submission (new method)
    @PostMapping("/payment/submit")
    public String submitPayment(@RequestParam("paymentMethod") String paymentMethod,
                               @RequestParam(value = "cardNumber", required = false) String cardNumber,
                               @RequestParam(value = "cardHolder", required = false) String cardHolder,
                               @RequestParam(value = "expires", required = false) String expires,
                               @RequestParam(value = "cvc", required = false) String cvc,
                               @RequestParam(value = "cardType", required = false) String cardType,
                               @RequestParam(value = "codName", required = false) String codName,
                               @RequestParam(value = "codPhone", required = false) String codPhone,
                               @RequestParam(value = "codAddress", required = false) String codAddress,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {
        try {
            if (userDetails == null) {
                redirectAttributes.addFlashAttribute("error", "Please log in to place an order");
                return "redirect:/login";
            }

            // Validate required fields based on payment method
            if ("card".equals(paymentMethod)) {
                if (cardNumber == null || cardNumber.trim().isEmpty() ||
                    cardHolder == null || cardHolder.trim().isEmpty() ||
                    expires == null || expires.trim().isEmpty() ||
                    cvc == null || cvc.trim().isEmpty()) {
                    redirectAttributes.addFlashAttribute("error", "Please fill all card details");
                    return "redirect:/payment";
                }
            } else if ("cod".equals(paymentMethod)) {
                if (codName == null || codName.trim().isEmpty() ||
                    codPhone == null || codPhone.trim().isEmpty() ||
                    codAddress == null || codAddress.trim().isEmpty()) {
                    redirectAttributes.addFlashAttribute("error", "Please fill all delivery details");
                    return "redirect:/payment";
                }
            }

            // Create and save the order
            Order order = new Order();
            order.setCustomerId(userDetails.getUserId());
            order.setServiceType("Wash & Fold"); // You can make this dynamic later
            order.setClothType("Mixed Items");
            order.setQuantity(1);
            order.setPrice(775.0); // Total amount including tax and delivery
            order.setNotes("Order placed via payment form - " + paymentMethod);
            order.setPaymentMethod(paymentMethod);
            order.setOrderDate(LocalDateTime.now());

            // Set payment status based on method - RESTORED VERIFICATION LOGIC
            if ("card".equals(paymentMethod)) {
                // Store card details for manager verification
                order.setCardNumber(cardNumber);
                order.setCardHolderName(cardHolder);
                order.setExpiryDate(expires);

                order.setPaymentStatus("PENDING_VERIFICATION"); // Needs manager approval
                order.setStatus("AWAITING_PAYMENT_VERIFICATION"); // Cannot proceed until verified
            } else {
                order.setPaymentStatus("PENDING"); // COD is pending until delivery
                order.setStatus("CONFIRMED"); // COD orders confirmed immediately
            }

            // Save the order
            Order savedOrder = orderService.saveOrder(order);

            if (savedOrder != null && savedOrder.getOrderId() != null) {
                String message = "card".equals(paymentMethod) ?
                    "Order submitted successfully! Payment verification is in progress. Order ID: " + savedOrder.getOrderId() :
                    "Order placed successfully! Pay on delivery. Order ID: " + savedOrder.getOrderId();
                redirectAttributes.addFlashAttribute("success", message);
                return "redirect:/customer-dashboard";
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to save order. Please try again.");
                return "redirect:/payment";
            }

        } catch (Exception e) {
            System.err.println("Error processing payment: " + e.getMessage());
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Payment processing failed: " + e.getMessage());
            return "redirect:/payment";
        }
    }

    // Keep the JSON API for backward compatibility
    @PostMapping("/payment/process")
    @ResponseBody
    public ResponseEntity<?> processPayment(@RequestBody PaymentRequest paymentRequest,
                                            @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            if (userDetails == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "User not authenticated"));
            }

            Long customerId = userDetails.getUserId();

            // Process each cart item as a separate order
            for (CartItem item : paymentRequest.getCartItems()) {
                Order order = new Order();
                order.setCustomerId(customerId);
                order.setServiceType(item.getServiceType());
                order.setClothType(item.getClothName());
                order.setQuantity(item.getQuantity());
                order.setPrice(item.getPrice());
                order.setNotes(item.getNotes());
                order.setPaymentMethod(paymentRequest.getPaymentMethod());
                order.setOrderDate(LocalDateTime.now());
                //order.setDeliveryDate(LocalDate .now().plusDays(2)); // Default delivery date

                // Extract and set special instructions and slot information from cart item
                if (item.getSpecialInstructions() != null && !item.getSpecialInstructions().trim().isEmpty()) {
                    order.setSpecialInstructions(item.getSpecialInstructions());
                }

                // Parse and set pickup date from pickup slot (format: "2025-09-30|09:00-12:00")
                if (item.getPickupSlot() != null && !item.getPickupSlot().trim().isEmpty()) {
                    try {
                        String[] slotParts = item.getPickupSlot().split("\\|");
                        if (slotParts.length > 0) {
                            order.setPickupDate(java.time.LocalDate.parse(slotParts[0]));
                        }
                    } catch (Exception e) {
                        System.err.println("Error parsing pickup slot: " + item.getPickupSlot());
                    }
                }

                // Parse and set delivery date from delivery slot (format: "2025-09-30|09:00-12:00")
                if (item.getDeliverySlot() != null && !item.getDeliverySlot().trim().isEmpty()) {
                    try {
                        String[] slotParts = item.getDeliverySlot().split("\\|");
                        if (slotParts.length > 0) {
                            order.setDeliveryDate(java.time.LocalDate.parse(slotParts[0]));
                        }
                    } catch (Exception e) {
                        System.err.println("Error parsing delivery slot: " + item.getDeliverySlot());
                    }
                }

                // Store card details if it's a card payment
                if ("card".equals(paymentRequest.getPaymentMethod()) && paymentRequest.getCardDetails() != null) {
                    CardDetails cardDetails = paymentRequest.getCardDetails();
                    order.setCardNumber(cardDetails.getCardNumber() != null ? cardDetails.getCardNumber() :
                                       cardDetails.getCardNumber());
                    order.setCardHolderName(cardDetails.getCardHolder() != null ? cardDetails.getCardHolder() :
                                           cardDetails.getCardHolderName());
                    order.setExpiryDate(cardDetails.getExpires() != null ? cardDetails.getExpires() :
                                       cardDetails.getExpiryDate());

                    order.setPaymentStatus("PENDING_VERIFICATION"); // Card payment needs verification
                    order.setStatus("PENDING"); // Order pending until payment verified
                } else {
                    order.setPaymentStatus("PENDING"); // COD is pending until delivery
                    order.setStatus("PENDING"); // Order pending until approved
                }

                orderService.saveOrder(order);
            }

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Order placed successfully!",
                    "paymentMethod", paymentRequest.getPaymentMethod()
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Payment processing failed: " + e.getMessage()));
        }
    }

    // DTO classes for payment processing
    public static class PaymentRequest {
        private List<CartItem> cartItems;
        private String paymentMethod;
        private double subtotal;
        private double tax;
        private double delivery;
        private double total;
        private CardDetails cardDetails;
        private CODDetails codDetails;

        // Getters and setters
        public List<CartItem> getCartItems() { return cartItems; }
        public void setCartItems(List<CartItem> cartItems) { this.cartItems = cartItems; }

        public String getPaymentMethod() { return paymentMethod; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

        public double getSubtotal() { return subtotal; }
        public void setSubtotal(double subtotal) { this.subtotal = subtotal; }

        public double getTax() { return tax; }
        public void setTax(double tax) { this.tax = tax; }

        public double getDelivery() { return delivery; }
        public void setDelivery(double delivery) { this.delivery = delivery; }

        public double getTotal() { return total; }
        public void setTotal(double total) { this.total = total; }

        public CardDetails getCardDetails() { return cardDetails; }
        public void setCardDetails(CardDetails cardDetails) { this.cardDetails = cardDetails; }

        public CODDetails getCodDetails() { return codDetails; }
        public void setCodDetails(CODDetails codDetails) { this.codDetails = codDetails; }
    }

    public static class CartItem {
        private String clothName;
        private String serviceType;
        private double price;
        private int quantity;
        private String notes;
        private String deliveryForm;
        private String imageUrl;
        private String pickupSlot;
        private String deliverySlot;
        private String specialInstructions;

        // Getters and setters
        public String getClothName() { return clothName; }
        public void setClothName(String clothName) { this.clothName = clothName; }

        public String getServiceType() { return serviceType; }
        public void setServiceType(String serviceType) { this.serviceType = serviceType; }

        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }

        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }

        public String getNotes() { return notes; }
        public void setNotes(String notes) { this.notes = notes; }

        public String getDeliveryForm() { return deliveryForm; }
        public void setDeliveryForm(String deliveryForm) { this.deliveryForm = deliveryForm; }

        public String getImageUrl() { return imageUrl; }
        public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

        public String getPickupSlot() { return pickupSlot; }
        public void setPickupSlot(String pickupSlot) { this.pickupSlot = pickupSlot; }

        public String getDeliverySlot() { return deliverySlot; }
        public void setDeliverySlot(String deliverySlot) { this.deliverySlot = deliverySlot; }

        public String getSpecialInstructions() { return specialInstructions; }
        public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    }

    public static class CardDetails {
        private String cardNumber;
        private String cardHolderName; // for backend
        private String cardHolder;     // for frontend flexibility
        private String expiryDate;     // for backend
        private String expires;        // for frontend flexibility
        private String cvc;
        private String cardType;

        // Getters and setters
        public String getCardNumber() { return cardNumber; }
        public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }

        public String getCardHolderName() { return cardHolderName; }
        public void setCardHolderName(String cardHolderName) { this.cardHolderName = cardHolderName; }

        public String getCardHolder() { return cardHolder; }
        public void setCardHolder(String cardHolder) { this.cardHolder = cardHolder; }

        public String getExpiryDate() { return expiryDate; }
        public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }

        public String getExpires() { return expires; }
        public void setExpires(String expires) { this.expires = expires; }

        public String getCvc() { return cvc; }
        public void setCvc(String cvc) { this.cvc = cvc; }

        public String getCardType() { return cardType; }
        public void setCardType(String cardType) { this.cardType = cardType; }
    }

    public static class CODDetails {
        private String fullName;
        private String phoneNumber;
        private String address;

        // Getters and setters
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }

        public String getPhoneNumber() { return phoneNumber; }
        public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

        public String getAddress() { return address; }
        public void setAddress(String address) { this.address = address; }
    }
}
