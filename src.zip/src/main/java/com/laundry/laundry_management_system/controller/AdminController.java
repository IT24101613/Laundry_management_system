package com.laundry.laundry_management_system.controller;

import com.laundry.laundry_management_system.model.User;
import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.service.UserService;
import com.laundry.laundry_management_system.service.OrderService;
import com.laundry.laundry_management_system.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    // Admin Dashboard
    @GetMapping("/admin-dashboard")
    public String showAdminDashboard(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            // Get the actual user object from the database
            User adminUser = userService.findById(userDetails.getUserId());

            // Initialize empty maps in case of errors
            Map<String, Object> salesStats = new HashMap<>();
            Map<String, Object> performanceStats = new HashMap<>();

            // Try to get sales statistics with error handling
            try {
                salesStats = getSalesStatistics();
            } catch (Exception e) {
                System.err.println("Error getting sales statistics: " + e.getMessage());
                // Set default values
                salesStats.put("totalOrders", 0);
                salesStats.put("completedOrders", 0);
                salesStats.put("pendingOrders", 0);
                salesStats.put("inProgressOrders", 0);
                salesStats.put("totalRevenue", 0.0);
                salesStats.put("totalActiveStaff", 0);
                salesStats.put("totalStaff", 0);
                salesStats.put("deliveryStaffCount", 0L);
                salesStats.put("regularStaffCount", 0L);
                salesStats.put("managerCount", 0L);
            }

            // Try to get performance statistics with error handling
            try {
                performanceStats = getPerformanceStatistics();
            } catch (Exception e) {
                System.err.println("Error getting performance statistics: " + e.getMessage());
                // Set default values
                performanceStats.put("completionRate", 0.0);
                performanceStats.put("avgOrderValue", 0.0);
                performanceStats.put("ordersPerStaff", 0.0);
            }

            model.addAttribute("admin", adminUser != null ? adminUser : new User());
            model.addAttribute("salesStats", salesStats);
            model.addAttribute("performanceStats", performanceStats);

            return "admin-dashboard";

        } catch (Exception e) {
            System.err.println("Error in admin dashboard controller: " + e.getMessage());

            // Add error message to model
            model.addAttribute("error", "Unable to load dashboard data. Please check system logs.");
            model.addAttribute("admin", new User());
            model.addAttribute("salesStats", new HashMap<>());
            model.addAttribute("performanceStats", new HashMap<>());

            return "admin-dashboard";
        }
    }

    // Staff Management Page
    @GetMapping("/staff")
    public String showStaffManagement(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        // Get the actual user object from the database
        User adminUser = userService.findById(userDetails.getUserId());

        List<User> staffList = userService.getUsersByRole("STAFF");
        staffList.addAll(userService.getUsersByRole("MANAGER"));
        staffList.addAll(userService.getUsersByRole("DELIVERY_STAFF"));

        model.addAttribute("staffList", staffList);
        model.addAttribute("admin", adminUser != null ? adminUser : new User());

        return "admin-staff";
    }

    // Add Staff Page
    @GetMapping("/staff/add")
    public String showAddStaff(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        // Get the actual user object from the database
        User adminUser = userService.findById(userDetails.getUserId());

        model.addAttribute("staff", new User());
        model.addAttribute("admin", adminUser != null ? adminUser : new User());

        return "admin-add-staff";
    }

    // Add Staff Process
    @PostMapping("/staff/add")
    public String addStaff(@ModelAttribute User staff,
                          RedirectAttributes redirectAttributes,
                          @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            User savedStaff = userService.saveUser(staff);
            if (savedStaff != null) {
                redirectAttributes.addFlashAttribute("success", "Staff member added successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to add staff. Email may already exist.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to add staff member.");
        }

        return "redirect:/admin/staff";
    }

    // Edit Staff Page
    @GetMapping("/staff/edit/{id}")
    public String showEditStaff(@PathVariable Long id, Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        // Get the actual user object from the database
        User adminUser = userService.findById(userDetails.getUserId());

        User staff = userService.findById(id);
        if (staff == null) {
            return "redirect:/admin/staff";
        }

        model.addAttribute("staff", staff);
        model.addAttribute("admin", adminUser != null ? adminUser : new User());

        return "admin-edit-staff";
    }

    // Update Staff Process
    @PostMapping("/staff/update/{id}")
    public String updateStaff(@PathVariable Long id,
                             @ModelAttribute User staff,
                             RedirectAttributes redirectAttributes,
                             @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            User existingStaff = userService.findById(id);
            if (existingStaff != null) {
                existingStaff.setFirstName(staff.getFirstName());
                existingStaff.setLastName(staff.getLastName());
                existingStaff.setEmail(staff.getEmail());
                existingStaff.setPhoneNumber(staff.getPhoneNumber());
                existingStaff.setRole(staff.getRole());
                existingStaff.setAddress(staff.getAddress());

                User updatedStaff = userService.saveUser(existingStaff);
                if (updatedStaff != null) {
                    redirectAttributes.addFlashAttribute("success", "Staff member updated successfully!");
                } else {
                    redirectAttributes.addFlashAttribute("error", "Failed to update staff member.");
                }
            } else {
                redirectAttributes.addFlashAttribute("error", "Staff member not found.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update staff member.");
        }

        return "redirect:/admin/staff";
    }

    // Delete Staff
    @PostMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id,
                             RedirectAttributes redirectAttributes) {
        try {
            boolean deleted = userService.deleteUser(id);
            if (deleted) {
                redirectAttributes.addFlashAttribute("success", "Staff member deleted successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to delete staff member.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete staff member.");
        }

        return "redirect:/admin/staff";
    }

    // Helper methods for statistics
    private Map<String, Object> getSalesStatistics() {
        Map<String, Object> stats = new HashMap<>();

        try {
            List<Order> allOrders = orderService.getAllOrders();
            List<Order> completedOrders = orderService.getOrdersByStatus("COMPLETED");
            List<Order> pendingOrders = orderService.getOrdersByStatus("PENDING");
            List<Order> inProgressOrders = orderService.getOrdersByStatus("IN_PROGRESS");

            stats.put("totalOrders", allOrders.size());
            stats.put("completedOrders", completedOrders.size());
            stats.put("pendingOrders", pendingOrders.size());
            stats.put("inProgressOrders", inProgressOrders.size());

            // Revenue statistics
            double totalRevenue = completedOrders.stream()
                .mapToDouble(order -> order.getPrice() != null ? order.getPrice() : 0.0)
                .sum();
            stats.put("totalRevenue", totalRevenue);

            // Staff statistics
            List<User> allStaff = userService.getUsersByRole("STAFF");
            List<User> managers = userService.getUsersByRole("MANAGER");
            List<User> deliveryStaff = userService.getUsersByRole("DELIVERY_STAFF");

            stats.put("totalActiveStaff", allStaff.size() + managers.size() + deliveryStaff.size());
            stats.put("totalStaff", allStaff.size() + managers.size() + deliveryStaff.size());
            stats.put("deliveryStaffCount", (long) deliveryStaff.size());
            stats.put("regularStaffCount", (long) allStaff.size());
            stats.put("managerCount", (long) managers.size());

        } catch (Exception e) {
            System.err.println("Error in getSalesStatistics: " + e.getMessage());
            // Return default values
            stats.put("totalOrders", 0);
            stats.put("completedOrders", 0);
            stats.put("pendingOrders", 0);
            stats.put("inProgressOrders", 0);
            stats.put("totalRevenue", 0.0);
            stats.put("totalActiveStaff", 0);
            stats.put("totalStaff", 0);
            stats.put("deliveryStaffCount", 0L);
            stats.put("regularStaffCount", 0L);
            stats.put("managerCount", 0L);
        }

        return stats;
    }

    private Map<String, Object> getPerformanceStatistics() {
        Map<String, Object> performance = new HashMap<>();

        try {
            List<Order> allOrders = orderService.getAllOrders();
            List<Order> completedOrders = orderService.getOrdersByStatus("COMPLETED");

            // Order completion rate
            if (!allOrders.isEmpty()) {
                double completionRate = (double) completedOrders.size() / allOrders.size() * 100;
                performance.put("completionRate", Math.round(completionRate * 100.0) / 100.0);
            } else {
                performance.put("completionRate", 0.0);
            }

            // Average order value
            if (!completedOrders.isEmpty()) {
                double avgOrderValue = completedOrders.stream()
                    .mapToDouble(order -> order.getPrice() != null ? order.getPrice() : 0.0)
                    .average().orElse(0.0);
                performance.put("avgOrderValue", Math.round(avgOrderValue * 100.0) / 100.0);
            } else {
                performance.put("avgOrderValue", 0.0);
            }

            // Staff productivity (orders per active staff)
            List<User> allStaff = userService.getUsersByRole("STAFF");
            List<User> managers = userService.getUsersByRole("MANAGER");
            List<User> deliveryStaff = userService.getUsersByRole("DELIVERY_STAFF");
            int totalStaffCount = allStaff.size() + managers.size() + deliveryStaff.size();

            if (totalStaffCount > 0 && !completedOrders.isEmpty()) {
                double ordersPerStaff = (double) completedOrders.size() / totalStaffCount;
                performance.put("ordersPerStaff", Math.round(ordersPerStaff * 100.0) / 100.0);
            } else {
                performance.put("ordersPerStaff", 0.0);
            }

        } catch (Exception e) {
            System.err.println("Error in getPerformanceStatistics: " + e.getMessage());
            // Return default values
            performance.put("completionRate", 0.0);
            performance.put("avgOrderValue", 0.0);
            performance.put("ordersPerStaff", 0.0);
        }

        return performance;
    }
}
