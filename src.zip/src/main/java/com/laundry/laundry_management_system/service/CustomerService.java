package com.laundry.laundry_management_system.service;

import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private OrderRepository orderRepository;

    // Simple method using customer ID
    public List<Order> getOrdersForCustomer(Long customerId) {
        return orderRepository.findByCustomerId(customerId);
    }

    // Get orders by customer ID and status
    public List<Order> getOrdersForCustomerByStatus(Long customerId, String status) {
        return orderRepository.findByCustomerIdAndStatus(customerId, status);
    }
}