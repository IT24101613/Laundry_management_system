package com.laundry.laundry_management_system.service;

import com.laundry.laundry_management_system.dto.UserRegistrationDto;
import com.laundry.laundry_management_system.model.User;
import java.util.List;

public interface UserService {
    boolean registerNewUser(UserRegistrationDto registrationDto);
    User findByEmail(String email);
    User findById(Long id);
    void save(User user);
    List<User> getUsersByRole(String role);
    User getUserById(Long userId);
    User saveUser(User user);
    boolean deleteUser(Long userId);
}