package com.laundry.laundry_management_system.service;


import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;
import com.laundry.laundry_management_system.model.Cart;
import com.laundry.laundry_management_system.model.CartItem;

@Service
public class CartService {
    public static final String CART_SESSION_KEY = "CART";

    public Cart getCart(HttpSession session) {
        Cart cart = (Cart) session.getAttribute(CART_SESSION_KEY);
        if (cart == null) {
            cart = new Cart();
            session.setAttribute(CART_SESSION_KEY, cart);
        }
        return cart;
    }

    public Cart addItem(HttpSession session, CartItem item) {
        Cart cart = getCart(session);
        cart.getItems().add(item);
        session.setAttribute(CART_SESSION_KEY, cart);
        return cart;
    }

    public Cart removeItem(HttpSession session, int index) {
        Cart cart = getCart(session);
        if (index >= 0 && index < cart.getItems().size()) {
            cart.getItems().remove(index);
            session.setAttribute(CART_SESSION_KEY, cart);
        }
        return cart;
    }

    public void clear(HttpSession session) {
        session.removeAttribute(CART_SESSION_KEY);
    }
}

