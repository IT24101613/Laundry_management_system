package com.laundry.laundry_management_system.service;

import com.laundry.laundry_management_system.model.DeliveryAvailability;
import com.laundry.laundry_management_system.repository.DeliveryAvailabilityRepository;
import com.laundry.laundry_management_system.model.Order;
import com.laundry.laundry_management_system.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DeliveryStaffService {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private DeliveryAvailabilityRepository availabilityRepository;

    // Get all orders assigned to a delivery staff
    public List<Order> getAssignedDeliveryOrders(Long deliveryStaffId) {
        return orderRepository.findByDeliveryStaffId(deliveryStaffId);
    }

    // Mark an order as delivered
    public boolean markOrderAsDelivered(Long orderId) {
        Order order = orderRepository.findById(orderId).orElse(null);
        if (order != null) {
            order.setStatus("DELIVERED");
            orderRepository.save(order);
            return true;
        }
        return false;
    }

    // Add a new availability slot
    public DeliveryAvailability addAvailability(DeliveryAvailability availability) {
        return availabilityRepository.save(availability);
    }

    // Update an existing slot
    public DeliveryAvailability updateAvailability(Long id, DeliveryAvailability updated) {
        DeliveryAvailability existing = availabilityRepository.findById(id).orElse(null);
        if (existing != null) {
            existing.setDate(updated.getDate());
            existing.setStartTime(updated.getStartTime());
            existing.setEndTime(updated.getEndTime());
            return availabilityRepository.save(existing);
        }
        return null;
    }

    // Get all slots for a staff member
    public List<DeliveryAvailability> getAvailabilityForStaff(Long staffId) {
        return availabilityRepository.findByStaffId(staffId);
    }

    // Get all future slots for customers
    public List<DeliveryAvailability> getFutureAvailability() {
        return availabilityRepository.findByDateAfter(LocalDate.now());
    }
}
