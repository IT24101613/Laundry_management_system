package com.laundry.laundry_management_system.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<CartItem> items = new ArrayList<>();

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public BigDecimal getTotal() {
        return items.stream()
                .map(i -> (i.getUnitPrice() == null ? BigDecimal.ZERO : i.getUnitPrice())
                        .multiply(BigDecimal.valueOf(Math.max(1, i.getQuantity()))))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
